{-# LANGUAGE GADTs, DataKinds, KindSignatures, RankNTypes, StandaloneDeriving #-}
module Ex08 where
import Data.List (delete)

data City = Sydney | Shanghai | Seoul | Singapore | Sapporo deriving (Eq, Show, Enum)

allCities :: [City]
allCities = [Sydney ..]

data SCity :: City -> * where
  SSydney    :: SCity Sydney
  SShanghai  :: SCity Shanghai
  SSeoul     :: SCity Seoul
  SSingapore :: SCity Singapore
  SSapporo   :: SCity Sapporo

untype :: SCity s -> City
untype SSydney    = Sydney
untype SShanghai  = Shanghai
untype SSeoul     = Seoul
untype SSingapore = Singapore
untype SSapporo   = Sapporo

withTyped :: City -> (forall c. SCity c -> b) -> b
withTyped Sydney    f = f SSydney
withTyped Shanghai  f = f SShanghai
withTyped Seoul     f = f SSeoul
withTyped Singapore f = f SSingapore
withTyped Sapporo   f = f SSapporo

data Flight :: City -> City -> * where
  NH880 :: Flight Sydney Sapporo
  SQ222 :: Flight Sydney Singapore
  KE122 :: Flight Sydney Seoul
  KE121 :: Flight Seoul Sydney
  SQ825 :: Flight Shanghai Singapore
  SQ231 :: Flight Singapore Sydney
  KE893 :: Flight Seoul Shanghai

deriving instance Show (Flight a b)

data Journey :: City -> City -> * where
  Fly :: Flight a b -> Journey a b
  Connect :: Journey a b -> Journey b c -> Journey a c

deriving instance Show (Journey a b)

flight :: SCity a -> SCity b -> Maybe (Flight a b)
flight _ _ = error "'flight' unimplemented"

journey :: [City] -> SCity a -> SCity b -> [Journey a b]
journey cities a b = error "'journey' unimplemented"



