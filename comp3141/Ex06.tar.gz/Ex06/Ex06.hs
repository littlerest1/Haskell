{-# LANGUAGE GADTs, EmptyDataDecls, TypeFamilies, TypeOperators, DataKinds, FlexibleInstances #-}
module Ex06 where


data Format (fmt :: [*])  where
  X :: Format '[]
--  L :: {- your type here -}
--  S :: {- your type here -} 
--  I :: {- your type here -}   

type family FormatArgsThen (fmt :: [*]) (ty :: *) :: *
type instance FormatArgsThen '[]       ty = ty
type instance FormatArgsThen (t ': ts) ty = t  -> FormatArgsThen ts ty  
     

printf :: Format fmt -> FormatArgsThen fmt String
printf fmt = printf' fmt ""
   where
      printf' :: Format fmt -> String -> FormatArgsThen fmt String
      printf' X str = str
      -- add other cases


